import wx


class HtmlHelpFrame(wx.Frame):

	def __init__(self, parent, id, title, opts):
		wx.Frame.__init__(self, parent, id, title, wx.DefaultPosition, wx.Size(640, 400))






